package com.example.expensecalculator;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class AddExpenseActivity extends AppCompatActivity {
    DatabaseHelper db;
    TextView dateTextView; // Change to TextView for date
    EditText amountEditText;
    EditText categoryEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        db = new DatabaseHelper(this);
        amountEditText = findViewById(R.id.amount_edit_text);
        categoryEditText = findViewById(R.id.category_edit_text);
        dateTextView = findViewById(R.id.date_text_view); // Updated to TextView
        Button saveButton = findViewById(R.id.save_button);

        // Set up the date picker dialog
        dateTextView.setOnClickListener(v -> showDatePickerDialog());

        saveButton.setOnClickListener(v -> {
            try {
                double amount = Double.parseDouble(amountEditText.getText().toString());
                String category = categoryEditText.getText().toString();
                String date = dateTextView.getText().toString(); // Get the formatted date
                if (date.isEmpty()) {
                    Toast.makeText(AddExpenseActivity.this, "Please select a date", Toast.LENGTH_SHORT).show();
                    return;
                }
                db.addExpense(amount, category, date);
                Toast.makeText(AddExpenseActivity.this, "Expense Added", Toast.LENGTH_SHORT).show();
                finish();
            } catch (NumberFormatException e) {
                Toast.makeText(AddExpenseActivity.this, "Invalid amount", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            // Format the date as "yyyy-MM-dd"
            String formattedDate = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
            dateTextView.setText(formattedDate); // Set the selected date to the TextView
        }, year, month, day);
        datePickerDialog.show();
    }
}