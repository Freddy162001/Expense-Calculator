package com.example.expensecalculator;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS_NAME = "AppPrefs";
    private static final String KEY_THEME = "theme";
    private int currentTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Load the saved theme
        loadTheme();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addExpenseButton = findViewById(R.id.add_expense_button);
        Button viewExpensesButton = findViewById(R.id.view_expenses_button);
        Button toggleThemeButton = findViewById(R.id.toggle_theme_button);

        addExpenseButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddExpenseActivity.class);
            startActivity(intent);
        });

        viewExpensesButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ExpenseListActivity.class);
            startActivity(intent);
        });

        toggleThemeButton.setOnClickListener(v -> {
            toggleTheme();
        });
    }

    private void toggleTheme() {
        if (currentTheme == AppCompatDelegate.MODE_NIGHT_YES) {
            currentTheme = AppCompatDelegate.MODE_NIGHT_NO; // Switch to Light Mode
        } else {
            currentTheme = AppCompatDelegate.MODE_NIGHT_YES; // Switch to Dark Mode
        }
        AppCompatDelegate.setDefaultNightMode(currentTheme);
        saveTheme(currentTheme);
    }

    private void loadTheme() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        currentTheme = preferences.getInt(KEY_THEME, AppCompatDelegate.MODE_NIGHT_NO);
        AppCompatDelegate.setDefaultNightMode(currentTheme);
    }

    private void saveTheme(int theme) {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_THEME, theme);
        editor.apply();
    }
}