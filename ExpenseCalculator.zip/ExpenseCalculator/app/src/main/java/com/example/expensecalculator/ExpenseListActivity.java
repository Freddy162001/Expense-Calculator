package com.example.expensecalculator;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ExpenseListActivity extends AppCompatActivity {
    DatabaseHelper db;
    ListView expenseListView;
    TextView totalExpensesTextView;
    ArrayList<Integer> expenseIds; // To hold expense IDs for deletion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_list);

        db = new DatabaseHelper(this);
        expenseListView = findViewById(R.id.expense_list_view);
        totalExpensesTextView = findViewById(R.id.total_expenses_text_view);
        loadExpenses();
    }

    private void loadExpenses() {
        Cursor cursor = db.getAllExpenses();
        ArrayList<String> expenses = new ArrayList<>();
        expenseIds = new ArrayList<>(); // Initialize the list to hold IDs
        double totalExpenses = 0.0;

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0); // Get the ID from the cursor
                double amount = cursor.getDouble(1);
                String category = cursor.getString(2);
                String date = cursor.getString(3);
                expenses.add("Amount: " + amount + ", Category: " + category + ", Date: " + date);
                expenseIds.add(id); // Add the ID to the list
                totalExpenses += amount;
            } while (cursor.moveToNext());
        }
        cursor.close();

        CustomAdapter adapter = new CustomAdapter(expenses);
        expenseListView.setAdapter(adapter);

        totalExpensesTextView.setText(String.format("Total Expenses: $%.2f", totalExpenses));
    }

    private class CustomAdapter extends ArrayAdapter<String> {
        public CustomAdapter(ArrayList<String> expenses) {
            super(ExpenseListActivity.this, R.layout.list_item_expense, expenses);
        }

        @Override
        public View getView(int position, View convertView, android.view.ViewGroup parent) {
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.list_item_expense, parent, false);
            }

            TextView expenseTextView = convertView.findViewById(R.id.expense_text_view);
            TextView deleteTextView = convertView.findViewById(R.id.delete_text_view); // Updated ID

            String expense = getItem(position);
            expenseTextView.setText(expense);

            deleteTextView.setOnClickListener(v -> {
                int idToDelete = expenseIds.get(position); // Get the ID to delete
                db.deleteExpense(idToDelete); // Delete from the database
                Toast.makeText(ExpenseListActivity.this, "Expense Deleted", Toast.LENGTH_SHORT).show();
                loadExpenses(); // Reload expenses
            });

            return convertView;
        }
    }
}